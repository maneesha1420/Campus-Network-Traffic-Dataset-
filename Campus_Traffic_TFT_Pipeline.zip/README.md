# Institutional network traffic preparation and TFT forecasting

## Using the attached dashboard today

The public_summary folder contains the prepared descriptive dataset, data dictionary, metadata and reuse instructions. It is the candidate deposit for institutional review. The training scripts and this guide can accompany a later hourly dataset. Publish only files covered by your institution's release authorization and chosen license. The original report contains internal identifiers.

To reproduce the summary, install Poppler (pdftotext on PATH), then run:
```sh
python dashboard.py "Traffic dashboard_1Sep2026_21Nov2026.pdf" public_summary
```
The extractor is specific to the supplied report and checked labels. The period totals cannot be converted into a measured hourly series.

## Installing the Python environment

Use a fresh Python 3.12 virtual environment. From the extracted directory:
```sh
python -m venv .venv
# Windows PowerShell
.venv\Scripts\Activate.ps1
# macOS/Linux shells instead use: source .venv/bin/activate
python -m pip install -r requirements.txt
```
For CPU-only Linux/Windows, install torch==2.6.0 from https://download.pytorch.org/whl/cpu with pip --index-url before installing requirements.txt. For GPU use a compatible PyTorch 2.6 build and driver. The code uses lightning.pytorch throughout. The pinned lightning and pytorch-lightning distributions match versions.

## Preparing an hourly dataset

Export one institution-wide total per completed hour. Required fields are timestamp (hour start, ISO date and time) and total_bytes (nonnegative bytes transferred during that hour). Use one consistent definition of total traffic throughout the file and document the directions and observation point. If using flow logs, derive these interval totals upstream with documented byte accounting for flows crossing hour boundaries. Cumulative counters need reset-aware differencing by the collector. A partial collector interval must be marked missing. A zero means the collector confirmed zero traffic. Optional columns are discarded during reading. CSV, CSV.GZ and Parquet inputs are supported.

```sh
python prepare.py hourly_export.csv prepared_hourly
python train.py prepared_hourly/hourly.csv.gz run_01
```

For alternate headers or an official academic closure calendar:
```sh
python prepare.py export.parquet prepared_hourly --time-col interval_start --bytes-col octets --holidays closures.csv
```
The calendar needs one date column with one YYYY-MM-DD per known closure. Only supply a complete calendar known at forecast time. Saturday/Sunday is a separate calendar indicator. Local times use Asia/Kolkata. The default exclusive cutoff is 11:00 IST on November 21, aligned to the last hour completed before the PDF snapshot. Change --end-exclusive only when the hourly export's verified coverage differs. A complete final day uses "2026-11-22 00:00". The release drops identifier columns entirely because campus aggregation makes persistent endpoint IDs unnecessary.

prepare.py builds a complete clock grid, records bad timestamp and target counts, and rejects duplicate or off-hour timestamps. Confirm missing timestamps against collection logs before use. Missing or infinite totals remain missing. Extreme high values are flagged using a train-only upper fence and retained. Gaps exclude every model window they touch. This can reduce evaluation coverage or prevent training when collection is sparse. Inspect metadata.json; report missing coverage alongside scores.

## Modeling and evaluation

Default history 48 hours, horizon 6 hours, stride 1 hour. The first floor(70% of scheduled hours) form training; validation ends at floor(85%); test gets the rest. History can cross a split boundary. Every forecast target stays in its own partition. Scaling and categorical encodings are fitted on training. GroupNormalizer scales historical volume by series. Only hour, weekday, weekend and optional closures are known future inputs. The source data has one campus series. The model uses 0.1, 0.5 and 0.9 quantile loss, early stopping, a validation-loss plateau learning-rate scheduler, automatic accelerator selection and ordered batches. Choose history, hyperparameters or training duration using validation alone. Use a fresh output directory for each run.

The selected checkpoint is the one with lowest validation loss. Test scores use its median prediction, clipped at zero and converted from MiB to bytes. Metrics are reported per lead and pooled over all forecast-origin/lead pairs; rolling origins may predict the same timestamp at different leads. SMAPE uses 200*|y-p|/(|y|+|p|), with zero for a zero/zero pair. A last-observation baseline uses the same origins. test_predictions.csv.gz contains the forecast issue time (start of the first predicted hour), target interval start, lead, actual, TFT forecast and baseline. training/version_0/metrics.csv contains validation loss, while test_metrics.csv and run.json summarize evaluation and window counts. PNG figures show TFT variable selection weights and attention over encoder lags for the first forecast hour. Attention and selection weights describe the fitted model, not causal effects. The single static group has no cross-campus variation.

Use actual observed hourly data to generate research scores and figures. The included PDF-derived data supports descriptive analysis only. No attack-classification labels were supplied.

## References

- IEEE DataPort submission guidance: https://innovate.ieee.org/dataport-update/
- PyTorch Forecasting 1.4 TFT API: https://pytorch-forecasting.readthedocs.io/en/v1.4.0/api/pytorch_forecasting.models.temporal_fusion_transformer._tft.TemporalFusionTransformer.html
