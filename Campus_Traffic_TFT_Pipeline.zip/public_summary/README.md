# Institutional Network Traffic by Application Category, Geography and Web Category

This descriptive dataset contains 20 category-level measurements extracted from four tables in an institutional firewall traffic dashboard. The selected reporting period begins September 1, 2026 at midnight, India Standard Time. The snapshot was generated November 21, 2026 at 11:35:47 IST. November 21 has partial coverage.

Open dashboard_summary.csv.gz directly with pandas.read_csv or decompress it for spreadsheet use. Filter by table first. For example, select Destination countries and rank rows by share_pct. Volume units are copied from the dashboard. Web categories use hit counts. The percentages are the appliance's displayed percentages and can reflect rounding. The source-country and destination-country tables describe different views of traffic. Summing their volumes double-counts traffic. “Others” is the source's residual category.

data_dictionary.csv documents columns and missing counts. metadata.json records provenance, scope and coverage. Only allowlisted aggregate categories are included. The raw report, individual hosts, domains, users, rule identifiers, upload records and appliance identifiers are excluded. This dataset supports aggregate analysis. It contains no time sequence or attack labels.

Suggested keywords: institutional network traffic, firewall telemetry, traffic volume, web traffic, aggregate statistics. Data format: gzip-compressed CSV, UTF-8. The depositor supplies authorship, institutional release approval and applicable distribution terms when submitting.
