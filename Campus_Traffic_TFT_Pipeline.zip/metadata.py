"""Describe exactly the columns and missing counts in a released table."""
import json
from pathlib import Path

import pandas as pd


def write_table(frame, directory, name, fields, metadata):
    if set(fields) != set(frame):
        raise ValueError("Dictionary does not match released columns.")
    dest = Path(directory)
    dest.mkdir(parents=True, exist_ok=True)
    frame.to_csv(dest / (name + ".csv.gz"), index=False, compression="gzip")
    rows = [(c, str(frame[c].dtype), *fields[c], int(frame[c].isna().sum())) for c in frame]
    pd.DataFrame(rows, columns=["name", "dtype", "unit", "description", "missing_count"]).to_csv(
        dest / "data_dictionary.csv", index=False)
    (dest / "metadata.json").write_text(json.dumps(dict(metadata, rows=len(frame)), indent=2))
