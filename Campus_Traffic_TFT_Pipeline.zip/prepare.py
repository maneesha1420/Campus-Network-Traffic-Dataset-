"""Prepare one institution-wide series from complete hour-start interval totals."""
import argparse

import numpy as np
import pandas as pd

from metadata import write_table

ZONE = "Asia/Kolkata"
START = pd.Timestamp("2026-09-01", tz=ZONE)
DEFAULT_END = "2026-11-21 11:00"  # exclusive; last completed hour starts at 10:00


def timestamp(value):
    try:
        t = pd.Timestamp(value)
        return t.tz_localize(ZONE) if t.tz is None else t.tz_convert(ZONE)
    except (TypeError, ValueError, OverflowError):
        return pd.NaT


def prepare(path, dest, time_col, bytes_col, end, holidays):
    stop = timestamp(end)
    if pd.isna(stop) or stop != stop.floor("h") or not START < stop <= timestamp("2026-11-22"):
        raise ValueError("End must be an exclusive whole-hour boundary within the study.")
    cols = [time_col, bytes_col]
    # Column projection prevents accidental inclusion of IPs or institutional identifiers.
    if path.lower().endswith(".parquet"):
        raw = pd.read_parquet(path, columns=cols)
    else:
        raw = pd.read_csv(path, usecols=cols, dtype="string")
    t = pd.to_datetime(raw[time_col].map(timestamp), utc=True).dt.tz_convert(ZONE)
    invalid_timestamps = int(t.isna().sum())
    inside = (t >= START) & (t < stop)
    t = t[inside]
    if t.duplicated().any() or (t != t.dt.floor("h")).any():
        raise ValueError("Expected one campus total per hour, timestamped at hour start. Check duplicates and interval semantics.")
    values = pd.to_numeric(raw.loc[inside, bytes_col], errors="coerce").astype(float)
    valid = np.isfinite(values) & (values >= 0) & (values == np.floor(values))
    grid = pd.date_range(START, stop, freq="h", inclusive="left")
    y = pd.Series(values.where(valid).to_numpy(), index=t).reindex(grid)
    n = len(grid)
    a, b = n * 70 // 100, n * 85 // 100
    if a == 0 or y.iloc[:a].count() < 2:
        raise ValueError("Insufficient observed training hours.")
    frame = pd.DataFrame({"timestamp": grid, "time_idx": np.arange(n), "series": "campus",
                          "bytes": y.to_numpy(), "split": np.select(
                              [np.arange(n) < a, np.arange(n) < b], ["train", "validation"], default="test")})
    frame["hour"] = grid.hour
    frame["weekday"] = grid.dayofweek
    frame["weekend"] = (grid.dayofweek >= 5).astype(int)
    fields = {"timestamp": ("ISO 8601", "Start of local measurement hour including UTC offset."),
              "time_idx": ("hours", "Elapsed hours since study start."),
              "series": ("category", "Single anonymous campus series."),
              "bytes": ("bytes/hour interval", "Total bytes in this hour. Missing means unknown; zero is observed."),
              "split": ("category", "Chronological assignment over all scheduled hours."),
              "hour": ("hour", "Local hour from 0 to 23."),
              "weekday": ("day", "Monday=0; Sunday=6."),
              "weekend": ("binary", "Saturday or Sunday; calendar convention.")}
    if holidays:
        dates = pd.to_datetime(pd.read_csv(holidays)["date"], format="%Y-%m-%d", errors="raise")
        if dates.isna().any():
            raise ValueError("Missing holiday date.")
        frame["holiday"] = np.isin(grid.date, dates.dt.date).astype(int)
        fields["holiday"] = ("binary", "Listed in supplied institutional closure calendar.")
    # Preserve genuine spikes; flag extremes by a threshold learned only from training.
    q1, q3 = y.iloc[:a].quantile([0.25, 0.75])
    fence = q3 + 3 * (q3 - q1)
    frame["high_outlier"] = (frame.bytes > fence).astype("Int64").mask(frame.bytes.isna())
    fields["high_outlier"] = ("binary", "Above train Q3 + 3*IQR; retained for forecasting.")
    write_table(frame, dest, "hourly", fields, {
        "timezone": ZONE, "end_exclusive": stop.isoformat(), "group": "campus",
        "clock_assumption": "Naive timestamps interpreted as Asia/Kolkata.",
        "invalid_timestamp_rows": invalid_timestamps,
        "outside_period_rows": len(raw) - len(t) - invalid_timestamps,
        "invalid_in_period_totals": int((~valid).sum()), "absent_hour_rows": n - len(t),
        "upper_outlier_fence_bytes": float(fence), "split_hours": frame.split.value_counts().to_dict(),
        "privacy": "Only campus hour totals retained. No IPs, domain names, users, filenames or keys."})


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("input")
    p.add_argument("output")
    p.add_argument("--time-col", default="timestamp")
    p.add_argument("--bytes-col", default="total_bytes")
    p.add_argument("--end-exclusive", default=DEFAULT_END)
    p.add_argument("--holidays", help="CSV with date column (YYYY-MM-DD)")
    args = p.parse_args()
    prepare(args.input, args.output, args.time_col, args.bytes_col, args.end_exclusive, args.holidays)
