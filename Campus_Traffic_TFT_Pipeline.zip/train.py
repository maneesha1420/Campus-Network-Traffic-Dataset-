"""Train a six-horizon campus traffic forecaster on observed hourly intervals."""
import argparse
from pathlib import Path
import json

import lightning.pytorch as pl
from lightning.pytorch.callbacks import EarlyStopping, ModelCheckpoint
from lightning.pytorch.loggers import CSVLogger
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch
from pytorch_forecasting import GroupNormalizer, TemporalFusionTransformer, TimeSeriesDataSet
from pytorch_forecasting.metrics import QuantileLoss
from sklearn.metrics import mean_absolute_error, root_mean_squared_error


def datasets(frame, history, horizon):
    observed = frame.bytes.notna()
    # Prefix sum counts missing hours in any candidate encoder + decoder in O(1).
    gaps = np.r_[0, np.cumsum(~observed)]
    data = frame.loc[observed].copy()
    data["volume_mib"] = data.bytes / 2**20
    known = ["hour", "weekday", "weekend"] + (["holiday"] if "holiday" in data else [])
    data[known] = data[known].astype(float)
    parts = []
    for label in ["train", "validation", "test"]:
        ids = frame.loc[frame.split.eq(label), "time_idx"]
        first, last = int(ids.min()), int(ids.max())
        rows = data[data.time_idx.between(max(0, first-history), last)]
        if label == "train":
            ds = TimeSeriesDataSet(rows, time_idx="time_idx", target="volume_mib", group_ids=["series"],
                static_categoricals=["series"], time_varying_known_reals=known,
                time_varying_unknown_reals=["volume_mib"], max_encoder_length=history,
                max_prediction_length=horizon, target_normalizer=GroupNormalizer(groups=["series"]),
                allow_missing_timesteps=True, randomize_length=False)
        else:
            ds = TimeSeriesDataSet.from_dataset(parts[0], rows, min_prediction_idx=first,
                                                stop_randomization=True)
        def complete_windows(idx):
            start = idx.time_idx_first.to_numpy()
            end = idx.time_idx_last.to_numpy()
            return ((gaps[end+1] == gaps[start]) & (idx.time_idx_first_prediction >= first)
                    & (end <= last))
        try:
            parts.append(ds.filter(complete_windows))
        except ValueError as exc:
            raise ValueError(f"No complete {label} windows with {history} history and {horizon} future hours.") from exc
    return parts


def score(table):
    y, yhat = table.actual_bytes.to_numpy(), table.forecast_bytes.to_numpy()
    denom = np.abs(y) + np.abs(yhat)
    return dict(n=len(y), mae_bytes=mean_absolute_error(y, yhat),
                rmse_bytes=root_mean_squared_error(y, yhat),
                smape_pct=200*np.divide(np.abs(y-yhat), denom, out=np.zeros_like(y), where=denom>0).mean())


def run(args):
    if args.history < 2 or args.horizon < 1:
        raise ValueError("History must be at least 2 and horizon at least 1.")
    out = Path(args.output)
    out.mkdir(parents=True, exist_ok=False)  # protect earlier research runs
    pl.seed_everything(42, workers=True)
    torch.set_num_threads(min(4, torch.get_num_threads()))
    frame = pd.read_csv(args.hourly).sort_values("time_idx").reset_index(drop=True)
    if not np.array_equal(frame.time_idx, np.arange(len(frame))):
        raise ValueError("Use the complete hourly grid written by prepare.py.")
    sets = datasets(frame, args.history, args.horizon)
    loaders = [s.to_dataloader(train=False, shuffle=False, batch_size=args.batch_size, num_workers=0) for s in sets]
    model = TemporalFusionTransformer.from_dataset(sets[0], hidden_size=16, attention_head_size=2,
        hidden_continuous_size=8, dropout=0.1, loss=QuantileLoss([0.1, 0.5, 0.9]), output_size=3,
        learning_rate=0.001, reduce_on_plateau_patience=2, optimizer="adam", log_interval=-1)
    ck = ModelCheckpoint(dirpath=out.resolve()/"checkpoints", monitor="val_loss", mode="min", save_top_k=1)
    trainer = pl.Trainer(accelerator="auto", devices=1, max_epochs=args.epochs,
        logger=CSVLogger(str(out), name="training"), gradient_clip_val=0.1,
        callbacks=[ck, EarlyStopping(monitor="val_loss", patience=6)], deterministic=True)
    trainer.fit(model, loaders[0], loaders[1])
    best = TemporalFusionTransformer.load_from_checkpoint(ck.best_model_path, map_location="cpu")
    best.eval()
    result = best.predict(loaders[2], mode="raw", return_index=True,
                          trainer_kwargs={"accelerator":"auto", "devices":1, "logger":False})
    forecast = result.output.prediction.detach().cpu().numpy()[:, :, 1]
    starts = result.index.time_idx.to_numpy()
    steps = np.arange(args.horizon)
    idx = starts[:, None] + steps
    predictions = pd.DataFrame({
        "origin": np.repeat(frame.timestamp.to_numpy()[starts], args.horizon),
        "timestamp": frame.timestamp.to_numpy()[idx].ravel(),
        "lead_hours": np.tile(steps+1, len(starts)),
        "actual_bytes": frame.bytes.to_numpy()[idx].ravel(),
        "forecast_bytes": np.maximum(0, forecast.astype(float).ravel()*2**20),
        "persistence_bytes": np.repeat(frame.bytes.to_numpy()[starts-1], args.horizon)})
    predictions.to_csv(out/"test_predictions.csv.gz", index=False)
    metrics = []
    for name, col in [("TFT", "forecast_bytes"), ("Persistence", "persistence_bytes")]:
        tbl = predictions.assign(forecast_bytes=predictions[col])
        for lead, sub in [("all", tbl), *tbl.groupby("lead_hours")]:
            metrics.append(dict(model=name, lead_hours=lead, **score(sub)))
    pd.DataFrame(metrics).to_csv(out/"test_metrics.csv", index=False)
    weights = best.interpret_output(result.output, reduction="sum", attention_prediction_horizon=0)
    for name, fig in best.plot_interpretation(weights).items():
        fig.savefig(out/(name+".png"), dpi=300, bbox_inches="tight")
        plt.close(fig)
    (out/"run.json").write_text(json.dumps({"windows":dict(zip(["train","validation","test"],map(len,sets))),
        "seed":42, "history":args.history, "horizon":args.horizon, "best_val_loss":ck.best_model_score.item(),
        "attention_lead_hours":1, "epochs_requested":args.epochs}, indent=2))


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("hourly")
    p.add_argument("output")
    p.add_argument("--history", type=int, default=48)
    p.add_argument("--horizon", type=int, default=6)
    p.add_argument("--epochs", type=int, default=40)
    p.add_argument("--batch-size", type=int, default=64)
    run(p.parse_args())
