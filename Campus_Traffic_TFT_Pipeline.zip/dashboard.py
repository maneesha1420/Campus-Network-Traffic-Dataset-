"""Extract only approved aggregate tables from the supplied report layout."""
import argparse
import re
import subprocess

import pandas as pd

from metadata import write_table

# A changed label must be reviewed before release. No host/domain/user strings pass through.
TABLES = {
    "2.Application categories": ["Infrastructure", "General Internet", "Software Update", "Streaming Media", "Others"],
    "5.Source countries": ["Reserved", "Unknown", "United States", "Netherlands", "Others"],
    "6.Destination countries": ["United States", "India", "Singapore", "United Kingdom", "Others"],
    "8.Web categories": ["Information Technology", "General Business", "Search Engines", "Content Delivery", "Others"],
}


def extract(pdf, destination):
    text = subprocess.check_output(["pdftotext", "-layout", pdf, "-"], encoding="utf-8")
    if "2026-09-01 00:00:00 - 2026-11-21 23:59:59" not in text.split("\f")[0] or "Sat Nov 21 11:35:47 IST 2026" not in text.split("\f")[0]:
        raise ValueError("Unexpected report period or snapshot time.")
    pages = {p.strip().splitlines()[0]: p for p in text.split("\f") if p.strip()}
    rows = []
    for title, labels in TABLES.items():
        for label in labels:
            pattern = r"^\s*" + re.escape(label) + r"[ \t]+([\d.]+)(?: (TB|GB|MB|KB|B))?[ \t]+([\d.]+)\s*%"
            hits = re.findall(pattern, pages[title], re.M)
            if len(hits) != 1:
                raise ValueError("Report layout changed: " + title)
            value, unit, share = hits[0]
            rows.append((title.split(".", 1)[1], label, float(value), unit or "hits", float(share)))
    fields = {"table": ("category", "Dashboard section; each has its own denominator."),
              "category": ("category", "Source label, including the residual Others bucket."),
              "value": ("see unit", "Published measurement at dashboard precision."),
              "unit": ("category", "Original volume unit or web hit count."),
              "share_pct": ("percent", "Share displayed by appliance, subject to rounding.")}
    write_table(pd.DataFrame(rows, columns=fields), destination, "dashboard_summary", fields,
                {"title": "Institutional Network Traffic by Application Category, Geography and Web Category",
                 "source": "Institutional firewall dashboard, unfiltered report",
                 "period_requested": ["2026-09-01", "2026-11-21"],
                 "snapshot_local": "2026-11-21T11:35:47+05:30", "timezone": "Asia/Kolkata",
                 "granularity": "One category per report section across the reporting period",
                 "limitations": "Final day partial. Sections overlap and must not be summed together. Only aggregate categories are released. No hourly targets or attack labels."})


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("pdf")
    parser.add_argument("output")
    args = parser.parse_args()
    extract(args.pdf, args.output)
